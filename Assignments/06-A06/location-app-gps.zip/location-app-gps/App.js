import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import BottomTabNavigator from './src/navigation/BottomTabNavigator'; // Adjust the path as necessary
// import TopTabNavigator from './src/navigation/TopTabNavigator'; 

export default function App() {
  return (
    <NavigationContainer>
      {/* <TopTabNavigator /> */}
      <BottomTabNavigator />
    </NavigationContainer>
  );
}