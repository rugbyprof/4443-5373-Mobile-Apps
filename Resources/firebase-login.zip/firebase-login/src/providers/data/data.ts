import { Injectable } from '@angular/core';
import { AngularFirestore } from 'angularfire2/firestore';
import {  map } from 'rxjs/operators';


/*
  Generated class for the DataProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class DataProvider {

  constructor(private firestore: AngularFirestore) {
    console.log('Hello DataProvider Provider');
  }

  async createUser(email: string, name: string) {
    let userCollection = this.firestore.collection<any>('users');
    try {
      await userCollection.add({
        name: name,
        email: email
      });
    } catch(e) {
      console.log(e);
      throw e;
    }
    
  }

  async getAllUsers() {
    let usersCollection = this.firestore.collection<any>('users', ref => 
    ref.where('name', '==', 'Shady'));
   // usersCollection.valueChanges().subscribe((users) => console.log(users));
   let users = usersCollection.snapshotChanges().pipe(map(actions => {
     return actions.map(action => {
       const id = action.payload.doc.id;
       const data = action.payload.doc.data();
       return {id, ...data};
     });
   }));
   users.subscribe((users) => console.log(users));
  }



}
