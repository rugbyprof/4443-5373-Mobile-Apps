export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyBMOvcn2v3_rk_zjcpwPjA-sMQd6-3FeVE",
    authDomain: "testapp-8b9e2.firebaseapp.com",
    databaseURL: "https://testapp-8b9e2.firebaseio.com",
    projectId: "testapp-8b9e2",
    storageBucket: "testapp-8b9e2.appspot.com",
    messagingSenderId: "672816596594"
};