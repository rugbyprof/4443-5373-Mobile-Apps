import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {FormBuilder, FormGroup, Validators} from '@angular/forms'
import { ThrowStmt } from '@angular/compiler';
import { DataProvider } from '../../providers/data/data';
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  loginForm: FormGroup;
  constructor(public navCtrl: NavController, public navParams: NavParams, private formBuilder:  FormBuilder, private data: DataProvider) {

    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }

  async login() {
    let email = this.loginForm.controls['email'].value;
    let password = this.loginForm.controls['password'].value;
    try {
      await this.data.createUser(email, 'Shady111');
    } catch(e) {

    }
    this.navCtrl.setRoot('HomePage');
   // this.navCtrl.push('HomePage');
  }

  async getUsers() {
    this.data.getAllUsers();
  }

}
