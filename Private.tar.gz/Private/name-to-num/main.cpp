#include <iostream>
#include <cmath>

using namespace std;

int main(int argc, char** argv){

    srand(1000);

    if(argc < 2){
        cout<<"Usage: myport yourlastname"<<endl;
        exit(0);
    }

    string name = argv[1];
    int port=0;
    int r=0;

    for(int i=0;i<name.length();i++){
        r = rand() % (int(pow(2,rand()%12)));
        port += int(name[i])*10+r;
    }

    cout<<"http://localhost:"<<port<<endl;

    return 0;
}