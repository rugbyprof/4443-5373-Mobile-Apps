export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAfIBizSb0L3F_Yu2fycJZJZESxVkTnoeA",
    authDomain: "msu-candy-store.firebaseapp.com",
    databaseURL: "https://msu-candy-store.firebaseio.com",
    projectId: "msu-candy-store",
    storageBucket: "msu-candy-store.appspot.com",
    messagingSenderId: "100839463519"
}
};