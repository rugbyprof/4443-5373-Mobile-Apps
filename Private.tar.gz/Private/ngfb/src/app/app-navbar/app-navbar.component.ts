import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './app-navbar.component.html',
  styleUrls: []
})
export class AppNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
