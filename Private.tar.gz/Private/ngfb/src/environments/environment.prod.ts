export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyD2HdwMX3IBLdTad8WeXxgyQJfTQayjzwk",
    authDomain: "video-games-f8e72.firebaseapp.com",
    databaseURL: "https://video-games-f8e72.firebaseio.com",
    projectId: "video-games-f8e72",
    storageBucket: "video-games-f8e72.appspot.com",
    messagingSenderId: "911053562452"
  }
};
